=== Real Membership ===
Contributors: Damyan Mirchev
Tags: anchor, text, generator, seo
Requires at least: 4.0
Tested up to: 5
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Tools List is a lite plugin for management of SEO tools.

== Installation ==

1. Upload the toolslist.zip archive to the /wp-content/plugins/ folder
2. Unzip the archive
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Enjoy :)

== Frequently Asked Questions ==

= How often do you plan to update the plugin =

Once or twice per month.

== Changelog ==

= 0.1.0 =
Initial release.
