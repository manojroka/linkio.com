<?php
/* DEPRECATED:
function st_is_valid_page_types($page_types) {
	if( empty($page_types) )
		return false;
	
	if( count($page_types) < 7 )
		return false;

	return true;
}

function st_is_valid_anchor_types($anchor_types) {
	if( empty($anchor_types) )
		return false;
	
	if( count($anchor_types) < 4 )
		return false;
	
	foreach($anchor_types as $anchor_type) {
		if($anchor_type == '')
			return false;
	}

	return true;
}
*/