<?php
// Anchor Generator version
define('TOOLS_LIST_VERSION', '0.1.0'); // Based on semver.org & keepachangelog.com

// Dependency versions
define('TOOLS_LIST_MINIMUM_PHP_VERSION', '5.3');
define('TOOLS_LIST_MINIMUM_WP_VERSION', '4.0');
